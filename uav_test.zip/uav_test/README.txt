把此文件放在~/example/src/下 编译

roslaunch uav_test uav_test.launch
即可打开相机，识别二维码，定点飞行，识别二维码，按预设位置投放物块，按二维码结果进行降落
