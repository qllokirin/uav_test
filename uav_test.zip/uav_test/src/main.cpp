#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/ActuatorControl.h>
#include <std_msgs/String.h>

double calculateDistance(const geometry_msgs::PoseStamped &point_a, const geometry_msgs::PoseStamped &point_b) {
    return sqrt(
            (point_a.pose.position.x - point_b.pose.position.x) * (point_a.pose.position.x - point_b.pose.position.x)
            + (point_a.pose.position.y - point_b.pose.position.y) * (point_a.pose.position.y - point_b.pose.position.y)
            +
            (point_a.pose.position.z - point_b.pose.position.z) * (point_a.pose.position.z - point_b.pose.position.z));
}

mavros_msgs::State current_state;

void stateCb(const mavros_msgs::State::ConstPtr &msg) {
    current_state = *msg;
}

geometry_msgs::PoseStamped pose_uav;

void poseCb(const geometry_msgs::PoseStamped::ConstPtr &msg) {
    pose_uav = *msg;
}

std::string qr_string;

void qrCb(const std_msgs::String::ConstPtr &msg) {
    qr_string = msg->data;
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "uav_test");
    ros::NodeHandle nh;

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>("/mavros/state", 10, stateCb);
    ros::Subscriber qr_sub = nh.subscribe<std_msgs::String>("/qr_detector/result", 10, qrCb);
    ros::Subscriber pose_sub = nh.subscribe<geometry_msgs::PoseStamped>("/mavros/local_position/pose", 10, poseCb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>("/mavros/setpoint_position/local", 10);
    ros::Publisher claw_pub_mix = nh.advertise<mavros_msgs::ActuatorControl>("/mavros/actuator_control", 1);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>("/mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>("/mavros/set_mode");

    ros::Rate rate(20.0);

    while (ros::ok() && !current_state.connected) {
        ros::spinOnce();
        rate.sleep();
    }

    mavros_msgs::ActuatorControl claw_control_mix;
    claw_control_mix.group_mix = 2;
    //-1是最小转动角度 1是最大角度
    for (int i = 0; i < 8; ++i) {
        claw_control_mix.controls[i] = -1;
    }

    geometry_msgs::PoseStamped pose;
    pose.pose.position.x = 0.0;
    pose.pose.position.y = 0.0;
    pose.pose.position.z = 1.2;

    ros::Time last_request = ros::Time::now();

    int state = 0;
    while (ros::ok()) {
        switch (state) {
            case 0:  // Wait for offboard
                ROS_INFO("waiting for take off");
                if (current_state.mode != "OFFBOARD") {
                    if (ros::Time::now() - last_request > ros::Duration(1.0)) {
                        mavros_msgs::SetMode offb_set_mode;
                        offb_set_mode.request.custom_mode = "OFFBOARD";
                        if (set_mode_client.call(offb_set_mode) && offb_set_mode.response.mode_sent) {
                            ROS_INFO("Offboard enabled");
                        }
                        last_request = ros::Time::now();
                    }
                    local_pos_pub.publish(pose);
                } else {
                    state = 1;
                }
                break;
            case 1:  // Wait for armed
                ROS_INFO("going to take off");
                if (!current_state.armed) {
                    if (ros::Time::now() - last_request > ros::Duration(1.0)) {
                        mavros_msgs::CommandBool arm_cmd;
                        arm_cmd.request.value = true;
                        if (arming_client.call(arm_cmd) && arm_cmd.response.success) {
                            ROS_INFO("Vehicle armed");
                            claw_pub_mix.publish(claw_control_mix);
                        }
                        last_request = ros::Time::now();
                    }
                    local_pos_pub.publish(pose);
                } else {
                    state = 2;
                    //初始化舵机角度
                    claw_pub_mix.publish(claw_control_mix);
                }
                break;
            case 2:  // Hover
                ROS_INFO("go to (0,0,1.2)");
                pose.pose.position.x = 0;
                pose.pose.position.y = 0;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 3:
                ROS_INFO("go to (0,1.6,1.2)");
                pose.pose.position.x = 0;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 4:
                ROS_INFO("go to (5.08,1.6,1.2)");
                pose.pose.position.x = 5.08;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 5:
                ROS_INFO("go to (5.08,0,1.2)");
                pose.pose.position.x = 5.08;
                pose.pose.position.y = 0;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    if (!qr_string.empty()) {
                        ROS_INFO("qr result : %s", qr_string.c_str());
                        state++;
                    }
                }
                break;
            case 6:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (5.88,1.6,0.6)");
                pose.pose.position.x = 5.88;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 7:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (5.88,1.6,0.6)");
                pose.pose.position.x = 5.88;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 0.6;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    //放下第一个物块
                    claw_control_mix.controls[0] = 1;
                    claw_control_mix.controls[7] = 1;
                    claw_pub_mix.publish(claw_control_mix);
                    state++;
                }
                break;
            case 8:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (3.92,1.6,0.6)");
                pose.pose.position.x = 3.92;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 9:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (3.92,1.6,0.6)");
                pose.pose.position.x = 3.92;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 0.6;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    //放下第二个物块
                    claw_control_mix.controls[1] = 1;
                    claw_control_mix.controls[6] = 1;
                    claw_pub_mix.publish(claw_control_mix);
                    state++;
                }
                break;
            case 10:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (1.96,1.6,0.6)");
                pose.pose.position.x = 1.96;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    state++;
                }
                break;
            case 11:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (1.96,1.6,0.6)");
                pose.pose.position.x = 1.96;
                pose.pose.position.y = 1.6;
                pose.pose.position.z = 0.6;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    //放下第三个物块
                    claw_control_mix.controls[2] = 1;
                    claw_control_mix.controls[5] = 1;
                    claw_pub_mix.publish(claw_control_mix);
                    state++;
                }
                break;
            case 12:
                ROS_INFO("qr result : %s", qr_string.c_str());
                ROS_INFO("go to (1.96,1.6,0.6)");
                pose.pose.position.x = 0;
                pose.pose.position.y = (qr_string[6] == 'l') ? 1.6 : -1.6;
                pose.pose.position.z = 1.2;
                local_pos_pub.publish(pose);
                if (calculateDistance(pose, pose_uav) < 0.2) {
                    for (int i = 0; i < 8; ++i) {
                        //舵机全打开
                        claw_control_mix.controls[i] = 1;
                        claw_pub_mix.publish(claw_control_mix);
                    }
                    state++;
                }
                break;
            case 13:  // Land
                ROS_INFO("land");
                if (current_state.mode != "AUTO.LAND") {
                    if (ros::Time::now() - last_request > ros::Duration(1.0)) {
                        mavros_msgs::SetMode land_set_mode;
                        land_set_mode.request.custom_mode = "AUTO.LAND";
                        if (set_mode_client.call(land_set_mode) && land_set_mode.response.mode_sent) {
                            ROS_INFO("Vehicle landed");
                        }
                        last_request = ros::Time::now();
                    }
                } else {
                    state++;
                }
                break;
            case 14:  // End
                return 0;
        }
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}


